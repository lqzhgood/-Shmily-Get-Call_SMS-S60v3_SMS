dbshell v.1.2 
If you new to this tool please see the readme file.
If you new to the symbian dbms please take info at symbian resources!
New in this version
 - changing the separator letter.
 - showing indexes
 - reading sql scripts in a text(csv) file.
 - exporting or importing a table data from/to a text(csv) file
 - date time  handling(still under development)

new command's templates:

sql>separator SEPARATOR
sql>indexes TABLENAME
sql>readin FILENAME 
sql>import TABLENAME FILENAME
sql>export TABLENAME FILENAME


examples for new commands:

sql>separator |
Changes the separator to '|'. 

sql>indexes dictable
shows indexes on table 'dictable' for the open database.

sql>readin readin_sample.txt
reads sql scripts in 'readin_sample.txt' file for executing on the open database. the file must be saved in unicode encoding. you should save your file in notepad (file/save as... encoding/unicode).
And the file must contain sql commands only:
create table, drop table, alter table,  create index, drop index, insert, update, delete.
One command must be in one line!

Sql>create table t1 (moment time, event char(100))

sql>insert into t1 values (#05/04/2010 06:00:00 pm#, 'tommy party')
Timestamp type data inserting.

sql>import table1 c:\import_sample.txt
imports data in c:\import_sample.txt to table1. The file must be saved in unicode encoding.
Please verify your file in notepad (file/save as...).
your file's format must be csv(comma separated values). But mustn't contain character " or '.

sql>export table1 c:\export_sample.txt
exports data in table1 to file c:\export_sample.txt. 
After exporting, always open the exported file in notepad and save it(file/save or crtl+s).

This program is still under development. So maybe errors or bugs.
Please feel free to send me email: garawaa@gmail.com
And I'm looking for a sponsor. Please donate this project. I am developing this project so slowly because financial problem.
Thanks!

Some web resources:
http://www.forum.nokia.com
http://www.wiki.forum.nokia.com
http://mdictionary.sf.net
http://developer.symbian.org
http://www.newlc.com
