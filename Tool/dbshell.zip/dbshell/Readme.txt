dbshell demo version!
This is a command line shell tool for native symbian dbms(old name is epoc!). It operates as other sql shells like Mysql, Sqlite... Maybe this tool very helful for symbian c++ developers who want to develop aplications for symbian smartphones. Today there are many smartphones use the symbian os. for example nokia n-series, e-series, sony ericson's uiq e.c.
For more information please visit forum.nokia.com web site.
System requirement:
A pc running in windows.
A writeble storage device.

New in this version
- opening and closing a database without exiting
- describe command added. usage: sql>describe tablename
- some bug fix

Examples of opening and closing databases:
sql>open database example.db
sql>close database

How to use:

first you need open or create a database. Use following:
1.Open windwows cmd prompt.
2.Go dbshell folder. for example: cd c:\dbshell
3.Run command dbshell database_name. for example: dbshell mydb.db 
The database will be created in in current folder. for example c:\dbshell\mydb.db
you can use also full path for database name. for example: dbshell d:\mydb.db 

If database not exists it creates new database. Else tries to open existing one!
For sql commands just type it. 

Known issues or problems

Currently there is no full support available for select statement. (time, data, binary,long binary types not implemented yet!)
Currently not possible execute muliple quiries at once.
and so on. :-)
No import export!

This is first release of the program. So maybe many bugs or errors.
If you detect bugs or have an idea, please feel free to send me an email. My email address is garawaa@gmail.com 
Thanks
